'use client';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Clock, MessageCircle } from "lucide-react";
import { motion } from "framer-motion";

export default function OfferPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-100 to-white flex flex-col">
      <header className="py-6 px-4 md:px-10 flex justify-between items-center">
        <h1 className="text-2xl font-bold">Automação Clínica Pro</h1>
        <Button asChild className="hidden md:block">
          <a href="https://wa.me/55xxxxxxxxx?text=Quero%20diagn%C3%B3stico%20gratuito">Diagnóstico Gratuito</a>
        </Button>
      </header>

      <main className="flex-1 flex flex-col items-center text-center px-4">
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-4xl md:text-5xl font-extrabold max-w-3xl leading-tight"
        >
          Encha sua agenda <span className="text-purple-600">e libere a sua secretária</span>
        </motion.h2>
        <p className="mt-4 max-w-xl text-lg text-gray-700">
          Automação inteligente de WhatsApp que responde clientes, confirma consultas, envia lembretes e recupera faltas — tudo em até 7 dias.
        </p>

        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4 w-full max-w-5xl">
          <Card>
            <CardContent className="p-6 flex flex-col items-center">
              <CheckCircle className="w-10 h-10 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Sem furos de agenda</h3>
              <p className="text-gray-600 text-center">Lembretes automáticos diminuem faltas e atrasos.</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 flex flex-col items-center">
              <Clock className="w-10 h-10 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Economia de tempo</h3>
              <p className="text-gray-600 text-center">Secretária foca no atendimento presencial — o robô cuida do WhatsApp.</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6 flex flex-col items-center">
              <MessageCircle className="w-10 h-10 mb-4" />
              <h3 className="text-xl font-semibold mb-2">Mais clientes</h3>
              <p className="text-gray-600 text-center">Follow‑up automático converte leads esquecidos em agendamentos.</p>
            </CardContent>
          </Card>
        </div>

        <Button size="lg" className="mt-10 animate-bounce" asChild>
          <a href="https://wa.me/55xxxxxxxxx?text=Quero%20diagn%C3%B3stico%20gratuito">Quero meu diagnóstico gratuito</a>
        </Button>

        <section className="mt-16 max-w-4xl">
          <h3 className="text-2xl font-bold mb-6">Como funciona</h3>
          <div className="grid md:grid-cols-3 gap-6 text-left">
            <div>
              <h4 className="font-semibold mb-2">1. Diagnóstico</h4>
              <p>Entendemos seu fluxo de atendimento e mensagens atuais.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">2. Implementação em 7 dias</h4>
              <p>Criamos e integramos o chatbot ao seu WhatsApp Business e agenda.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-2">3. Acompanhamento</h4>
              <p>Monitoramos por 30 dias, otimizando respostas e garantindo resultados.</p>
            </div>
          </div>
        </section>

        <section className="mt-16 max-w-3xl text-left">
          <h3 className="text-2xl font-bold mb-6 text-center">Investimento</h3>
          <div className="bg-white rounded-2xl shadow-xl p-8">
            <p className="text-lg mb-2"><strong>Setup:</strong> a partir de <strong>R$497</strong></p>
            <p className="text-lg mb-4"><strong>Mensalidade:</strong> <strong>R$297</strong> (suporte + otimizações)</p>
            <p className="text-gray-600 text-sm">Cancelamento livre a qualquer momento. Garantia de satisfação de 30 dias.</p>
          </div>
        </section>
      </main>

      <footer className="py-6 text-center text-sm text-gray-500">
        © {new Date().getFullYear()} Automação Clínica Pro · Feito com ☕ e muito foco
      </footer>
    </div>
  );
}